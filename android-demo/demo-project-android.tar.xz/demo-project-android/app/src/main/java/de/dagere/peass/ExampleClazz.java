package de.dagere.peass;

public class ExampleClazz {

    protected void calleeMethod() {
        new Callee().method1();
    }

}
